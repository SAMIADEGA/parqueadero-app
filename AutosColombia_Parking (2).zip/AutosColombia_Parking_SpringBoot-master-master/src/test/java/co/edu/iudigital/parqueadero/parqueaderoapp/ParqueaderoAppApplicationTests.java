package co.edu.iudigital.parqueadero.parqueaderoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParqueaderoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
