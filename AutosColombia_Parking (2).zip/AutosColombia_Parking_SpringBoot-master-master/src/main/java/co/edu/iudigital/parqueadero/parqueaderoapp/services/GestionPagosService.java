package co.edu.iudigital.parqueadero.parqueaderoapp.services;

import org.springframework.stereotype.Service;

@Service
public class GestionPagosService {
    
}
