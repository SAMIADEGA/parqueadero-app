package co.edu.iudigital.parqueadero.parqueaderoapp.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "gestionar_pagos")
public class GestionPagos {
    
    private int id;
    

}
